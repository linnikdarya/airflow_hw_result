import glob
import json
import os
from datetime import datetime

import dill
import pandas as pd


path = '/opt/airflow'


def predict():

    model_filename = sorted(os.listdir(f'{path}/data/models'))[-1]
    with open(f'{path}/data/models/{model_filename}', 'rb') as file:
        model = dill.load(file)

    df_pred = pd.DataFrame(columns=['car_id', 'pred'])
    files_list = os.listdir(f'{path}/data/test')

    for file in files_list:
        with open(f'{path}/data/test/{file}') as fin:
            form = json.load(fin)
        df = pd.DataFrame.from_dict([form])
        y = model.predict(df)
        x = {'car_id': df.id, 'pred': y}
        data = pd.DataFrame(x)
        df_pred = pd.concat([df_pred, data], axis=0)

    df_pred.to_csv(f'{path}/data/predictions/pred_{datetime.now().strftime("%Y%m%d%H%M")}.csv', index=False)


if __name__ == '__main__':
    predict()
